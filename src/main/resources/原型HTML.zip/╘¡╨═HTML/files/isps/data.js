﻿$axure.loadCurrentPage(
(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,c,d,e,f,g,h,g,i,[j],k,_(l,m,n,o,p,q,r,_(),s,_(t,u,v,w,x,_(y,z,A,B),C,null,D,w,E,w,F,G,H,null,I,J,K,L,M,N,O,P),Q,_(R,_()),S,_(),T,_(U,[])),V,_(),W,_());}; 
var b="url",c="isps.html",d="generationDate",e=new Date(1517478933971.16),f="isCanvasEnabled",g=false,h="isAdaptiveEnabled",i="variables",j="OnLoadVariable",k="page",l="packageId",m="9d90dba3ef224230b36af0742df3b590",n="type",o="Axure:Page",p="name",q="ISPS",r="notes",s="style",t="baseStyle",u="627587b6038d43cca051c114ac41ad32",v="pageAlignment",w="near",x="fill",y="fillType",z="solid",A="color",B=0xFFFFFFFF,C="image",D="imageHorizontalAlignment",E="imageVerticalAlignment",F="imageRepeat",G="auto",H="favicon",I="sketchFactor",J="34",K="colorStyle",L="appliedColor",M="fontName",N="Applied Font",O="borderWidth",P="0",Q="adaptiveStyles",R="a",S="interactionMap",T="diagram",U="objects",V="masters",W="objectPaths";
return _creator();
})());